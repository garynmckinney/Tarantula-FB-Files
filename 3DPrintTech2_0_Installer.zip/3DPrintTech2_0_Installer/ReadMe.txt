Use the Old aluminum spacers that came with the Rostock Max V2.  These hold the E3D V6 Hot by the aluminum collar at the top.  One fits through the narrow neck, the other fits over it to hold the hot end firmly.  The Aluminum spacers are just a bit better and more secure. I personally, will be using some PVC pipe dope on my and PVC glue to hold the two sections together.

You will need to do scaling.  That just means printing two circles, on inside the other.  One one Centimeter in diameter and the other ten cenimeters.  The first to be a tube one centimeter high, and the other to be ten cenimeters high.  Z has a different scaling correction factor than X and Y.

Here's the math to use in your CAD programs.  I'm certain you'll have to print this twice, if you're going to mount your E3D V6 printer head snuggly and properly.

http://www.mathsisfun.com/numbers/percentage-change.html

Print the 1cm cube.  Measure it with your caliper.  Since it is suppose to be 10 mm by 10 mm by 10 mm, correct for X,Y and Z using scaling before you run slic3r and print.  So, print the cube first for the correction factors.